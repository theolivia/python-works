name = input("Name: ")
print("hello, "+name)
