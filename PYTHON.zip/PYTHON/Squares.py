def square(x):
  return x*x

for i in range(101):
  print(f"The square of {i} is {square(i)}")
