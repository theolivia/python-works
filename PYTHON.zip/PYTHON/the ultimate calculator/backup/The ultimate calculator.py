import math
from subprocess import STARTF_USESTDHANDLES
from sys import api_version
from tkinter.colorchooser import askcolor
from tkinter.font import BOLD
import turtle
from typing import AnyStr
from tkinter import *
import pyaudio
from speech_recognition import Recognizer

name = input("Name: ")

if name == ("help"):
    print("here is a list of commands...")
    print("1. real (opens a real calculator)")
    print("2. realsci(opens a real scientific looking calculator)")
    print("3. realdark (opens a real calculator in dark mode)")
    print("4. wincalc(it opens the windows official calculator)")
    print("5. csload(loads in custom mode)")
    print("6. reveal(to reveal developer info)")
    print("7. to load in normal mode, enter your name")
    print("8. voice (loads voice calculator)")
    print("9. realvoice(to load a real voice calculator in html)")
    print("10.equate (to put equations)")
    name = input("Name: ")

if name == ("realvoice"):
    print("loading in html")
    import os
    dir = 'index.html'
    os.startfile(dir)
    exit()

if name == ("voice"):
    print("loading.....")
    import operator
    import speech_recognition as s_r
    r = s_r.Recognizer()
    my_mic_device = s_r.Microphone(device_index=1)
    with my_mic_device as source:
        print("Say what you want to calculate, example: 3 plus 3")
        r.adjust_for_ambient_noise(source)
        audio = r.listen(source)
    my_string=r.recognize_google(audio)
    print(my_string)
    def get_operator_fn(op):
        return {
            '+' : operator.add,
            '-' : operator.sub,
            'x' : operator.mul,
            'divided' :operator.__truediv__,
            'Mod' : operator.mod,
            'mod' : operator.mod,
            '^' : operator.xor,
            }[op]
    def eval_binary_expr(op1, oper, op2):
        op1,op2 = int(op1), int(op2)
        return get_operator_fn(oper)(op1, op2)
    print(eval_binary_expr(*(my_string.split())))
    input()




if name == ("wincalc"):
    dir = 'C:\Windows\System32\calc.exe'
    import os
    os.startfile(dir)
    os.system(dir)
    exit()
    import subprocess
    subprocess.Popen([dir])
    subprocess.call(dir)
    exit()




if name == ("csload"):
    print("loading in custom mode....")
    xnum = int(input("first number: "))
    ynum = int(input("second number: "))
    z= input("which operation would you like? ")
    if z == ("help"):
        print("here is a list of commands")
        print("1. addition")
        print("2. subtraction")
        print("3. multiplication")
        print("4. division")
        print("5. square and square root")
        print("6. cube or cube root")
        z = input("which operation would you like? ")

    if z == ("addition"):
        print(f"{xnum} added to {ynum} is {xnum+ynum}")
        input()

    if z == ("subtraction"):
        print(f"{xnum} subtracted from to {ynum} is {xnum-ynum}")
        input()

    if z == ("multiplication"):
        print(f"{xnum} multiplied to {ynum} is {xnum*ynum}")
        input()

    if z == ("division"):
        print(f"{xnum} divided to {ynum} is {xnum/ynum}")
        input()

    if z == ("square"):
        print(f"{xnum} square = {xnum*xnum}")
        print(f"{ynum} square = {ynum*ynum}")
        input()

    if z == ("cube"):
        print(f"{xnum} cube = {xnum*xnum*xnum}")
        print(f"{ynum} cube = {ynum*ynum*ynum}")
        input()

    if z == ("square root"):
        print(f"{xnum} square root = {math.sqrt(xnum)}")
        print(f"{ynum} square root = {math.sqrt(ynum)}")
        input()

    if z == ("cube root"):
        print(f"{xnum} cube root = {xnum**(1/3)}")
        print(f"{ynum} cube root = {ynum**(1/3)}")
        input()

if name == ("equate"):
    import re

    print("loading....")
    print("Type x to close")

    previous = 0
    run = True
    def performMath():
        global run
        global previous
        equation = ""
        if previous == 0:
            equation = input("Enter Equation: ")
        else :
            equation = input(str(previous))


        if equation == 'x':
            print("GoodBye!!!")
            exit(0)
        else:
            equation = re.sub('[a-zA-Z,:()" "]',"",equation)

        if previous == 0:
            previous = eval(equation)
        else:
            previous = eval(str(previous) + equation)

    while run:
        performMath()

if name == ("realsci"):
    print("ok loading in scientific mode.......")
    from tkinter import*
    import math
    import tkinter.messagebox

    root = Tk()
    root.title("Scientific Calculator")
    root.iconbitmap('calc.ico')
    root.configure(background="Powder blue")
    root.resizable(width=False, height=False)
    root.geometry("480x624+20+20")

    calc = Frame(root)
    calc.grid()

    class Calc():
        def __init__(self):
            self.total=0
            self.current=""
            self.input_value=True
            self.check_sum=False
            self.op=""
            self.result=False
        def numberEnter(self, num):
            self.result=False
            firstnum=textDisplay.get()
            secondnum=str(num)
            if self.input_value:
                self.current=secondnum
                self.input_value=False
            else:
                if secondnum=='.':
                    if secondnum in firstnum:
                        return
                self.current=firstnum+secondnum
            self.display(self.current)

        def sum_of_total(self):
            self.result=True
            self.current=float(self.current)
            if self.check_sum==True:
                self.valid_function()
            else:
                self.total=float(textDisplay.get())

        def valid_function(self):
            if self.op=="add":
                self.total+=self.current
            if self.op=="sub":
                self.total-=self.current
            if self.op=="multi":
                self.total*=self.current
            if self.op=="divide":
                self.total/=self.current
            if self.op=="mod":
                self.total%=self.current
            if self.op=="inv":
                self.total=1/self.current
            self.input_value=True
            self.check_sum=False
            self.display(self.total)

        def operation(self, op):
            self.current=float(self.current)
            if self.check_sum:
                self.valid_function()
            elif not self.result:
                self.total=self.current
                self.input_value=True
            self.check_sum=True
            self.op=op
            self.result=False

        def Clear_Entry(self):
            self.result=False
            self.current="0"
            self.display(0)
            self.input_value=True

        def all_Clear_Entry(self):
            self.Clear_Entry()
            self.total=0

        def tanh(self):
            self.reult=False
            self.current=math.tanh(math.radians(float(textDisplay.get())))
            self.display(self.current)

        def tanh(self):
            self.reult=False
            self.current=math.tanh(math.radians(float(textDisplay.get())))
            self.display(self.current)

        def tan(self):
            self.reult=False
            self.current=math.tan(math.radians(float(textDisplay.get())))
            self.display(self.current)

        def sinh(self):
            self.reult=False
            self.current=math.sinh(math.radians(float(textDisplay.get())))
            self.display(self.current)

        def sin(self):
            self.reult=False
            self.current=math.sin(math.radians(float(textDisplay.get())))
            self.display(self.current)

        def log(self):
            self.reult=False
            self.current=math.log(float(textDisplay.get()))
            self.display(self.current)

        def exp(self):
            self.reult=False
            self.current=math.exp(float(textDisplay.get()))
            self.display(self.current)

        def mathsPM(self):
            self.reult=False
            self.current=-(float(textDisplay.get()))
            self.display(self.current)

        def squared(self):
            self.reult=False
            self.current=math.sqrt(float(textDisplay.get()))
            self.display(self.current)

        def cos(self):
            self.reult=False
            self.current=math.cos(math.radians(float(textDisplay.get())))
            self.display(self.current)

        def cosh(self):
            self.reult=False
            self.current=math.cosh(math.radians(float(textDisplay.get())))
            self.display(self.current)


        def display(self, value):
            textDisplay.delete(0, END)
            textDisplay.insert(0, value)

        def pi(self):
            self.reult=False
            self.current=math.pi
            self.display(self.current)


        def tau(self):
            self.reult=False
            self.current=math.tau
            self.display(self.current)

        def e(self):
            self.reult=False
            self.current=math.e
            self.display(self.current)

        def acosh(self):
            self.result=False
            self.current=math.acosh(float(textDisplay.get()))
            self.display(self.current)

        def asinh(self):
            self.result=False
            self.current=math.asinh(float(textDisplay.get()))
            self.display(self.current)

        def expm1(self):
            self.result=False
            self.current=math.expm1(float(textDisplay.get()))
            self.display(self.current)

        def lgamma(self):
            self.result=False
            self.current=math.lgamma(float(textDisplay.get()))
            self.display(self.current)

        def degrees(self):
            self.result=False
            self.current=math.degrees(float(textDisplay.get()))
            self.display(self.current)

        def log2(self):
            self.result=False
            self.current=math.log2(float(textDisplay.get()))
            self.display(self.current)

        def log10(self):
            self.result=False
            self.current=math.log10(float(textDisplay.get()))
            self.display(self.current)

        def log1p(self):
            self.result=False
            self.current=math.log1p(float(textDisplay.get()))
            self.display(self.current)

    added_value=Calc()

    textDisplay = Entry(calc, relief=SUNKEN, font=('arial', 20, 'bold'), bg="powder blue", bd=30, width=28, justify=RIGHT)
    textDisplay.grid(row=0, column=0, columnspan=4, pady=1)
    textDisplay.insert(0, "0")

    numberpad = "789456123"
    i=0
    btn=[]
    for j in range(2,5):
        for k in range(3):
            btn.append(Button(calc, width=6, height=2, font=('arial', 20, 'bold'), bd=4, text=numberpad[i]))
            btn[i].grid(row=j, column=k, pady=1)
            btn[i]["command"]=lambda x=numberpad[i]: added_value.numberEnter(x)
            i+=1

    btnClear=Button(calc, text=chr(67), width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="powder blue", command=added_value.Clear_Entry).grid(row=1, column=0, pady=1)
    btnAllClear=Button(calc, text=chr(67)+chr(69), width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="powder blue", command=added_value.all_Clear_Entry).grid(row=1, column=1, pady=1)

    btnSq=Button(calc, text="√", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="powder blue", command=added_value.squared).grid(row=1, column=2, pady=1)
    btnAdd=Button(calc, text="+", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="powder blue", command=lambda:added_value.operation("add")).grid(row=1, column=3, pady=1)

    btnSub=Button(calc, text="-", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="powder blue", command=lambda:added_value.operation("sub")).grid(row=2, column=3, pady=1)
    btnMult=Button(calc, text="×", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="powder blue", command=lambda:added_value.operation("multi")).grid(row=3, column=3, pady=1)

    btnDiv=Button(calc, text=chr(247), width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="powder blue", command=lambda:added_value.operation("divide")).grid(row=4, column=3, pady=1)
    btnZero=Button(calc, text="0", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="powder blue", command=lambda:added_value.numberEnter(0)).grid(row=5, column=0, pady=1)

    btnDot=Button(calc, text=".", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="powder blue", command=lambda:added_value.numberEnter(".")).grid(row=5, column=1, pady=1)
    btnPM=Button(calc, text=chr(177), width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="powder blue", command=added_value.mathsPM).grid(row=5, column=2, pady=1)

    btnEquals=Button(calc, text="=", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="powder blue", command=added_value.sum_of_total).grid(row=5, column=3, pady=1)


    btnPi=Button(calc, text='π', width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="Aqua", command=added_value.pi).grid(row=1, column=4, pady=1)
    btnCos=Button(calc, text="cos", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="Aqua", command=added_value.cos).grid(row=1, column=5, pady=1)

    btnTan=Button(calc, text="tan", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="Aqua", command=added_value.tan).grid(row=1, column=6, pady=1)
    btnSin=Button(calc, text="sin", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="Aqua", command=added_value.sin).grid(row=1, column=7, pady=1)

    btn2Pi=Button(calc, text='2π', width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="Aqua", command=added_value.tau).grid(row=2, column=4, pady=1)
    btnCosh=Button(calc, text="cosh", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="gray", command=added_value.cosh).grid(row=2, column=5, pady=1)

    btnTanh=Button(calc, text="tanh", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="gray", command=added_value.tanh).grid(row=2, column=6, pady=1)
    btnSinh=Button(calc, text="sinh", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="gray", command=added_value.sinh).grid(row=2, column=7, pady=1)

    btnLog=Button(calc, text='log', width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="Aqua", command=added_value.log).grid(row=3, column=4, pady=1)
    btninv=Button(calc, text="Inv", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="gray", command=lambda:added_value.operation("inv")).grid(row=3, column=5, pady=1)

    btnMod=Button(calc, text="Mod", width=6, height=2, font=('arial', 20, 'bold'), bd=4, command=lambda:added_value.operation("mod")).grid(row=3, column=6, pady=1)
    btnE=Button(calc, text="e", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="gray", command=added_value.e).grid(row=3, column=7, pady=1)

    btnLog2=Button(calc, text='log2', width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="Aqua", command=added_value.log2).grid(row=4, column=4, pady=1)
    btnDeg=Button(calc, text="deg", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="gray", command=added_value.degrees).grid(row=4, column=5, pady=1)

    btnAcosh=Button(calc, text="acosh", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="gray", command=added_value.acosh).grid(row=4, column=6, pady=1)
    btnAsinh=Button(calc, text="asinh", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="gray", command=added_value.asinh).grid(row=4, column=7, pady=1)

    btnLog10=Button(calc, text='log10', width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="Aqua", command=added_value.log10).grid(row=5, column=4, pady=1)
    btnLog1p=Button(calc, text="log1p", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="Aqua", command=added_value.log1p).grid(row=5, column=5, pady=1)

    btnExpm1=Button(calc, text="expm1", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="Aqua", command=added_value.expm1).grid(row=5, column=6, pady=1)
    btnLgamma=Button(calc, text="lgamma", width=6, height=2, font=('arial', 20, 'bold'), bd=4, bg="Aqua", command=added_value.lgamma).grid(row=5, column=7, pady=1)

    lblDisplay=Label(calc, text="Scientific Calculator", font=('arial', 30, 'bold'), justify =CENTER)
    lblDisplay.grid(row=0, column=4, columnspan=4)

    lblDisplay=Label(calc, text="Arul Sinha", font=('arial', 30, 'bold'), justify =CENTER)
    lblDisplay.grid(row=6, column=0, columnspan=4)

    def iExit():
        iExit = tkinter.messagebox.askyesno("Scientific Calculator", "Are you sure you want to exit")
        if iExit>0:
            root.destroy()
            return

    def Scientific():
        root.resizable(width=False, height=False)
        root.geometry("944x624+20+20")

    def Standard():
        root.resizable(width=False, height=False)
        root.geometry("480x624+20+20")

    menubar = Menu(calc)


    filemenu = Menu(menubar, tearoff=0)
    menubar.add_cascade(label = "File", menu=filemenu)
    filemenu.add_command(label = "Standadrd", command = Standard)
    filemenu.add_command(label = "Scientific", command = Scientific)
    filemenu.add_separator()
    filemenu.add_command(label = "Exit", command = iExit)

    root.config(menu=menubar)
    root.mainloop()
    exit()


if name == ("realdark"):
    print("loading in real dark mode.........")
    import tkinter
    from tkinter import*
    from tkinter import messagebox

    val = ""
    A = 0
    operatordark = ""

    def btn1_click():
        global val
        val = val + "1"
        data.set(val)

    def  btn2_click():
        global val
        val = val + "2"
        data.set(val)

    def btn3_click():
        global val
        val = val + "3"
        data.set(val)

    def btn4_click():
        global val
        val = val + "4"
        data.set(val)

    def btn5_click():
        global val
        val = val + "5"
        data.set(val)

    def btn6_click():
        global val
        val = val + "6"
        data.set(val)

    def btn7_click():
        global val
        val = val + "7"
        data.set(val)

    def btn8_click():
        global val
        val = val + "8"
        data.set(val)

    def btn9_click():
        global val
        val = val + "9"
        data.set(val)

    def btn0_click():
        global val
        val = val + "0"
        data.set(val)

    def btn_plusClicked():
        global A
        global operatordark
        global val
        A = int(val)
        operatordark = "+"
        val = val + "+"
        data.set(val)

    def btn_minusClicked():
        global A
        global operatordark
        global val
        A = int(val)
        operatordark = "-"
        val = val + "-"
        data.set(val)

    def btn_multiClicked():
        global A
        global operatordark
        global val
        A = int(val)
        operatordark = "*"
        val = val + "*"
        data.set(val)

    def btn_divideClicked():
        global A
        global operatordark
        global val
        A = int(val)
        operatordark = "/"
        val = val + "/"
        data.set(val)

    def cPressed():
        global A
        global operatordark
        global val
        val = ""
        A = 0
        operatordark = ""
        data.set(val)

    def result():
        global A
        global operatordark
        global val
        val2 = val
        if operatordark == "+":
            x2 = int((val2.split("+")[1]))
            y2 = A + x2
            data.set(y2)
            val = str(y2)
        elif operatordark == "-":
            x2 = int((val2.split("-")[1]))
            y2 = A - x2
            data.set(y2)
            val = str(y2)
        elif operatordark == "*":
            x2 = int((val2.split("*")[1]))
            y2 = A * x2
            data.set(y2)
            val = str(y2)
        elif operatordark == "/":
            x2 = int((val2.split("/")[1]))
            y2 = A / x2
            data.set(y2)
            val = str(y2)



    root = tkinter.Tk()
    root.geometry("250x400+300+300")
    root.resizable(0,0)
    root.title("calculator")
    root.iconbitmap('calc.ico')

    btnrow1 = Frame(root,bg = "black")
    btnrow1.pack(expand = True, fill = "both")

    btnrow2 = Frame(root,bg = "black")
    btnrow2.pack(expand=True, fill = "both")

    btnrow3 = Frame(root,bg = "black")
    btnrow3.pack(expand=True, fill = "both")

    btnrow4 = Frame(root,bg = "black")
    btnrow4.pack(expand=True, fill = "both")

    data = StringVar()
    lbl = Label(
        root, text = "Lable", anchor = N,fg = "yellow",bg = "dark blue",font=("comic sans ms",20),textvariable = data
        )
    lbl.pack(expand = True,fill = "both")

    calcbtn1 = Button(
        btnrow1,
        text = "1",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = btn1_click
    )
    calcbtn1.pack(side = LEFT,expand = True,fill = "both")

    calcbtn2 = Button(
        btnrow1,
        text = "2",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = btn2_click
    )
    calcbtn2.pack(side = LEFT,expand = True,fill = "both")

    calcbtn3 = Button(
        btnrow1,
        text = "3",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = btn3_click
    )
    calcbtn3.pack(side = LEFT,expand = True,fill = "both")

    calcbtn4 = Button(
        btnrow1,
        text = "4",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = btn4_click
    )
    calcbtn4.pack(side = LEFT,expand = True,fill = "both")






    calcbtn5 = Button(
        btnrow2,
        text = "5",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = btn5_click
    )
    calcbtn5.pack(side = LEFT,expand = True,fill = "both")

    calcbtn6 = Button(
        btnrow2,
        text = "6",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = btn6_click
    )
    calcbtn6.pack(side = LEFT,expand = True,fill = "both")

    calcbtn7 = Button(
        btnrow2,
        text = "7",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = btn7_click
    )
    calcbtn7.pack(side = LEFT,expand = True,fill = "both")

    calcbtn8 = Button(
        btnrow2,
        text = "8",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = btn8_click
    )
    calcbtn8.pack(side = LEFT,expand = True,fill = "both")



    calcbtn9 = Button(
        btnrow3,
        text = "9",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = btn9_click
    )
    calcbtn9.pack(side = LEFT,expand = True,fill = "both")

    calcbtnC = Button(
        btnrow3,
        text = "c",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = cPressed
    )
    calcbtnC.pack(side = LEFT,expand = True,fill = "both")

    calcbtnEQuals = Button(
        btnrow3,
        text = "=",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = result
    )
    calcbtnEQuals.pack(side = LEFT,expand = True,fill = "both")

    calcbtn0 = Button(
        btnrow3,
        text = "0",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = btn0_click
    )
    calcbtn0.pack(side = LEFT,expand = True,fill = "both")



    calcbtnMU = Button(
        btnrow4,
        text = "x",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = btn_multiClicked
    )
    calcbtnMU.pack(side = LEFT,expand = True,fill = "both")

    calcbtnDivi = Button(
        btnrow4,
        text = "÷",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = btn_divideClicked
    )
    calcbtnDivi.pack(side = LEFT,expand = True,fill = "both")

    calcbtnAdd = Button(
        btnrow4,
        text = "+",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = btn_plusClicked
    )
    calcbtnAdd.pack(side = LEFT,expand = True,fill = "both")

    calcbtnSub = Button(
        btnrow4,
        text = "-",
        font = ("arial",22),
        fg = "red",
        bg = "black",
        relief = GROOVE,
        border = 0,
        command = btn_minusClicked
    )
    calcbtnSub.pack(side = LEFT,expand = True,fill = "both")






    root.mainloop()
    exit()




if name  == ("real"):
    print("loading in real mode")
    from tkinter import*
    def btnClick(numbers):
        global operator
        operator=operator + str(numbers)
        text_Input.set(operator)

    def btnClearDisplay():
        global operator
        operator=""
        text_Input.set("")

    def btnEqualsInput():
        global operator
        sumup=str(eval(operator))
        text_Input.set(sumup)
        operator=""


    cal = Tk()
    cal.title("calculator")
    operator=""
    text_Input =StringVar()
    textDisplay = Entry(cal,font=('arial',20,'bold'), textvariable=text_Input, bd=30,insertwidth=4,bg="powder blue", justify='right').grid(columnspan=4)
    btn7=Button(cal,padx=16,bd=8,fg="black",font=('arial',20,'bold'),text="7",command=lambda:btnClick(7)) .grid(row=1,column=0)
    btn8=Button(cal,padx=16,bd=8,fg="black",font=('arial',20,'bold'),text="8",command=lambda:btnClick(8)) .grid(row=1,column=1)
    btn9=Button(cal,padx=16,bd=8,fg="black",font=('arial',20,'bold'),text="9",command=lambda:btnClick(9)) .grid(row=1,column=2)
    Addition=Button(cal,padx=16,bd=8,fg="black",font=('arial',20,'bold'),text="+",command=lambda:btnClick("+")) .grid(row=1,column=3)
    #========================================
    btn4=Button(cal,padx=16,bd=8,fg="black",font=('arial',20,'bold'),text="4",command=lambda:btnClick(4)) .grid(row=2,column=0)
    btn5=Button(cal,padx=16,bd=8,fg="black",font=('arial',20,'bold'),text="5",command=lambda:btnClick(5)) .grid(row=2,column=1)
    btn6=Button(cal,padx=16,bd=8,fg="black",font=('arial',20,'bold'),text="6",command=lambda:btnClick(6)) .grid(row=2,column=2)
    subtraction=Button(cal,padx=16,bd=8,fg="black",font=('arial',20,'bold'),text="-",command=lambda:btnClick("-")) .grid(row=2,column=3)
    #=========================================
    btn1=Button(cal,padx=16,bd=8,fg="black",font=('arial',20,'bold'),text="1",command=lambda:btnClick(1)) .grid(row=3,column=0)
    btn2=Button(cal,padx=16,bd=8,fg="black",font=('arial',20,'bold'),text="2",command=lambda:btnClick(2)) .grid(row=3,column=1)
    btn3=Button(cal,padx=16,bd=8,fg="black",font=('arial',20,'bold'),text="3",command=lambda:btnClick(3)) .grid(row=3,column=2)
    multiplication=Button(cal,padx=16,bd=8,fg="black",font=('arial',20,'bold'),text="*",command=lambda:btnClick("*")) .grid(row=3,column=3)
    #===========================================
    btn0=Button(cal,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="0",command=lambda:btnClick(0)) .grid(row=4,column=0)
    btnclear=Button(cal,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="C",command=btnClearDisplay) .grid(row=4,column=1)
    btnequals=Button(cal,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="=",command=btnEqualsInput) .grid(row=4,column=2)
    division=Button(cal,padx=16,pady=16,bd=8,fg="black",font=('arial',20,'bold'),text="/",command=lambda:btnClick("/")) .grid(row=4,column=3)
    cal.mainloop()
    exit()




if name == ("reveal"):
    print("ok reveling developer information............")
    print("develoers name is Arul Sinha who lives in india he was 13 years old when he created this code")
    input()

print("hello, "+name)
print("please fill these numbers")
x= int(input("first number: "))
y= int(input("second number: "))

print("=====================================")

print(f"{x} added to {y} is {x+y}")
print(f"{y} subtracted from {x} is {x-y}")
print(f"{x} multiplied to {y} is {x*y}")
print(f"{x} divided to {y} is {x/y}")

print("-------------------------------------")

print(f"{x} square is {x*x}")
print(f"{x} cube is {x*x*x}")

print("-------------------------------------")

print(f"{y} square is {y*y}")
print(f"{y} cube is {y*y*y}")

print("-------------------------------------")

print(f"the table of {x} is...")
print(f"{x} x 1 = {x}")
print(f"{x} x 2 = {x*2}")
print(f"{x} x 3 = {x*3}")
print(f"{x} x 4 = {x*4}")
print(f"{x} x 5 = {x*5}")
print(f"{x} x 6 = {x*6}")
print(f"{x} x 7 = {x*7}")
print(f"{x} x 8 = {x*8}")
print(f"{x} x 9 = {x*9}")
print(f"{x} x 10 = {x*10}")

print("-------------------------------------")

print(f"the table of {y} is...")
print(f"{y} x 2 = {y*2}")
print(f"{y} x 3 = {y*3}")
print(f"{y} x 4 = {y*4}")
print(f"{y} x 5 = {y*5}")
print(f"{y} x 6 = {y*6}")
print(f"{y} x 7 = {y*7}")
print(f"{y} x 8 = {y*8}")
print(f"{y} x 9 = {y*9}")
print(f"{y} x 10 = {y*10}")

print("-------------------------------------")

print(f"square root of {x} is {math.sqrt(x)} ")
print(f"cube root of {x} is {x**(1/3)}")

print("-------------------------------------")

print(f"square root of {y} is {math.sqrt(y)} ")
print(f"cube root of {y} is {y**(1/3)}")

print("-------------------------------------")

print(f"cos {x} = {math.cos(x)}")
print(f"sin {x} = {math.sin(x)}")
print(f"tan {x} = {math.tan(x)}")

print("-------------------------------------")

print(f"cos {y} = {math.cos(y)}")
print(f"sin {y} = {math.sin(y)}")
print(f"tan {y} = {math.tan(y)}")

print("-------------------------------------")

if (x%2 ==0):
    print(f"{x} is an even number")

else:
    print(f"{x} is a odd number")
print("-------------------------------------")

if (y%2 ==0):
    print(f"{y} is an even number")

else:
    print(f"{y} is a odd number")

print("=====================================")

like = input(f"Did you like it {name}? ")

if like == ("yes"):
    print("thank you, "+name)

if like == ("no"):
    print("sorry will improve, "+name)

if like == ("hurry"):
    exit()


print("=====================================")

operation = input("would you like more? if yes, which operation would you like? ")


if operation == ("help"):
    print("here are a list of commands:")
    print("1. cosh")
    print("2. sinh")
    print("3. tanh")
    print("4. floor")
    print("5. factorial")
    print("6. degrees")
    print("7. log")
    print("8. color resistor code finder(rs code)")
    print("9. perimetre")
    print("10. area")
    print("11. draw")
    print("12. currency")
    print("13. siunits")
    print("14. time")
    print("15. graph")
    print("16. rgb color finder(rgb)")
    operation = input("would you like more? if yes, which operation would you like? ")

if operation == ("time"):
    from tkinter import *
    from tkinter.ttk import *
    from time import strftime
    root = Tk()
    root.title('Clock')
    root.iconbitmap('calc.ico')
    def time():
        string = strftime('%H:%M:%S %p')
        lbl.config(text = string)
        lbl.after(1000, time)
    lbl = Label(root, font = ('calibri', 40, 'bold'),
            background = 'purple',
            foreground = 'white')
    lbl.pack(anchor = 'center')
    time()

    mainloop()
    exit()

if operation == ("currency"):
    currency = input("enter currency: ")
    value = int(input("amount: "))
    if currency == ("help"):
        print("yen,rupees,american dollars,canadian dollars,australian dollars,pounds are supported")
        currency = input("enter currency: ")
    if currency == ("us dollar"):
        print(f"${value} in rupees is ₹{value*73}")
        print(f"${value} in pounds is €{value*0.74}")
        print(f"${value} in yen is ¥{value*109}")
        print(f"${value} in canadian dollar is ${value*1.21}")
        print(f"${value} in australian dollar is ${value*1.29}")
        print(f"${value} in franc is ₣{value*0.9}")
        input()

    if currency == ("can dollar"):
        print(f"${value} in rupees is ₹{value*60}")
        print(f"${value} in pounds is €{value*0.59}")
        print(f"${value} in yen is ¥{value*90}")
        print(f"${value} in american dollar is ${value*0.38}")
        print(f"${value} in australian dollar is ${value*1.07}")
        print(f"${value} in franc is ₣{value*0.74}")
        input()

    if currency == ("rupees"):
        print(f"₹{value} in american dollar is ${value*0.73}")
        print(f"₹{value} in pounds is €{value*0.0097}")
        print(f"₹{value} in yen is ¥{value*2}")
        print(f"₹{value} in canadian dollar is ${value*0.017}")
        print(f"₹{value} in australian dollar is ${value*0.18}")
        print(f"₹{value} in franc is ₣{value*0.012}")
        input()

    if currency == ("aus dollar"):
        print(f"${value} in rupees is ₹{value*18}")
        print(f"${value} in pounds is €{value*0.55}")
        print(f"${value} in yen is ¥{value*83.37}")
        print(f"${value} in canadian dollar is ${value*0.94}")
        print(f"${value} in american dollar is ${value*0.77}")
        print(f"${value} in franc is ₣{value*0.69}")
        input()

    if currency == ("yen"):
        print(f"¥{value} in rupees is ₹{value*0.67}")
        print(f"¥{value} in pounds is €{value*0.0065}")
        print(f"¥{value} in american is ${value*0.0091}")
        print(f"¥{value} in canadian dollar is ${value*0.011}")
        print(f"¥{value} in australian dollar is ${value*0.012}")
        print(f"¥{value} in franc is ₣{value*0.0082}")
        input()

    if currency == ("franc"):
        print(f"₣{value} in rupees is ₹{value*12}")
        print(f"₣{value} in pounds is €{value*0.79}")
        print(f"₣{value} in yen is ¥{value*122.21}")
        print(f"₣{value} in canadian dollar is ${value*1.35}")
        print(f"₣{value} in australian dollar is ${value*1.44}")
        print(f"₣{value} in american dollar is ${value*1.12}")
        input()

    if currency == ("pound"):
        print(f"€{value} in rupees is ₹{value*103}")
        print(f"€{value} in american dollar is ${value*74}")
        print(f"€{value} in yen is ¥{value*65}")
        print(f"€{value} in canadian dollar is ${value*1.21}")
        print(f"€{value} in australian dollar is ${value*55}")
        print(f"€{value} in franc is ₣{value*0.79}")
        input()

if operation == ("siunit"):
    si = input("SI unit of what: ")
    if si == ("help"):
        print("here are a list of commands")
        print("mass,weight,volume")
        si = input("SI unit of what: ")

    if si == ("weight"):
        num = int(input("enter the weight in grams: "))
        print(f"{num}g = {1000000000000000000000*num} YotaTonne")
        print(f"{num}g = {1000000000000000000*num} TeraTonne ")
        print(f"{num}g = {1000000000000000*num} GigaTonne")
        print(f"{num}g = {100000000000*num} MegaTonne")
        print(f"{num}g = {1000000*num} Tonne")
        print(f"{num}g = {1000*num} KiloGram")
        print(f"{num}g = {100*num} HectoGram")
        print(f"{num}g = {10*num} DekaGram ")
        print(f"{num}g = {0.1*num} DeciGram ")
        print(f"{num}g = {0.01*num} CentiGram ")
        print(f"{num}g = {0.001*num } MilliGram ")
        print(f"{num}g = {0.000001*num} MicroGram ")
        print(f"{num}g = {0.00000001*num} NanoGram ")
        print(f"{num}g = {0.000000000001*num} PicoGram ")
        input()

    if si == ("mass"):
        num = int(input("enter the weight in grams: "))
        print(f"{num}g = {1000000000000000000000*num}YotaTonne")
        print(f"{num}g = {1000000000000000000*num}TeraTonne ")
        print(f"{num}g = {1000000000000000*num}GigaTonne")
        print(f"{num}g = {100000000000*num}MegaTonne")
        print(f"{num}g = {1000000*num}Tonne")
        print(f"{num}g = {1000*num}KiloGram")
        print(f"{num}g = {100*num}HectoGram")
        print(f"{num}g = {10*num}DekaGram ")
        print(f"{num}g = {0.1*num}DeciGram ")
        print(f"{num}g = {0.01*num}CentiGram ")
        print(f"{num}g = {0.001*num}MilliGram ")
        print(f"{num}g = {0.000001*num}MicroGram ")
        print(f"{num}g = {0.00000001*num}NanoGram ")
        print(f"{num}g = {0.000000000001*num}PicoGram ")
        input()

    if si == ("volume"):
        num = int(input("enter the weight in liters: "))
        print(f"{num}g = {1000*num} KiloLitre")
        print(f"{num}g = {100*num} HectoLitre")
        print(f"{num}g = {10*num} DekaLitre ")
        print(f"{num}g = {0.1*num} DeciLitre ")
        print(f"{num}g = {0.01*num} CentiLitre ")
        print(f"{num}g = {0.001*num} MilliLitre ")
        input()

    if si == ("force"):
        num1 = int(input("enter the mass in kg: "))
        num2 = int(input("enter the accelaration: "))
        print(f"force is {num1*num2}")
        input()

    if si == ("distance"):
        num = int(input("enter the weight in Metres: "))
        print(f"{num}m = {1000*num} KiloMetre")
        print(f"{num}m = {100*num} HectoMetre")
        print(f"{num}m = {10*num} DekaMetre ")
        print(f"{num}m = {0.1*num} DeciMetre ")
        print(f"{num}m = {0.01*num} CentiMetre ")
        print(f"{num}m = {0.001*num} MilliMetre")
        input()

    if si == ("time"):
        num = int(input("enter the time in minutes"))
        print("{num} minutes is {num*100} NanoSeconds")
        print("{num} minutes is {num*100} MicroSeconds")
        print("{num} minutes is {num/60} Hours")
        print("{num} minutes is {num/1440} Days")
        print("{num} minutes is {num/10080} Weeks")
        print("{num} minutes is {num/43200} Months")
        print("{num} minutes is {num/518400} Years")
        print("{num} minutes is {num/5184000} Decades")
        input()

    if si == ("speed"):
        num1 = int(input("enter distance: "))
        num2 = int(input("enter time: "))
        print(f"speed is {num1/num2}")
        input()

if operation == ("rgb"):
    print("loading....")
    from tkinter import colorchooser
    my_col = colorchooser.askcolor()


if operation == ("graph"):
    print("loading graph calculator")
    import tkinter as tk
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    from matplotlib.figure import Figure

    root= tk.Tk()
    root.title("graph calculator")
    root.iconbitmap('calc.ico')
    canvas1 = tk.Canvas(root, width = 800, height = 300)
    canvas1.pack()

    label1 = tk.Label(root, text='Grapg Calculator')
    label1.config(font=('Arial', 20))
    canvas1.create_window(400, 50, window=label1)

    entry1 = tk.Entry (root)
    canvas1.create_window(400, 100, window=entry1)

    entry2 = tk.Entry (root)
    canvas1.create_window(400, 120, window=entry2)

    entry3 = tk.Entry (root)
    canvas1.create_window(400, 140, window=entry3)
    def create_charts():
        global x1
        global x2
        global x3
        global bar1
        global pie2
        x1 = float(entry1.get())
        x2 = float(entry2.get())
        x3 = float(entry3.get())
        figure1 = Figure(figsize=(4,3), dpi=100)
        subplot1 = figure1.add_subplot(111)
        xAxis = [float(x1),float(x2),float(x3)]
        yAxis = [float(x1),float(x2),float(x3)]
        subplot1.bar(xAxis,yAxis, color = 'lightsteelblue')
        bar1 = FigureCanvasTkAgg(figure1, root)
        bar1.get_tk_widget().pack(side=tk.LEFT, fill=tk.BOTH, expand=0)

        figure2 = Figure(figsize=(4,3), dpi=100)
        subplot2 = figure2.add_subplot(111)
        labels2 = 'Label1', 'Label2', 'Label3'
        pieSizes = [float(x1),float(x2),float(x3)]
        my_colors2 = ['lightblue','lightsteelblue','silver']
        explode2 = (0, 0.1, 0)
        subplot2.pie(pieSizes, colors=my_colors2, explode=explode2, labels=labels2, autopct='%1.1f%%', shadow=True, startangle=90)
        subplot2.axis('equal')
        pie2 = FigureCanvasTkAgg(figure2, root)
        pie2.get_tk_widget().pack()


    def clear_charts():
        bar1.get_tk_widget().pack_forget()
        pie2.get_tk_widget().pack_forget()

    button1 = tk.Button (root, text=' Create Charts ',command=create_charts, bg='palegreen2', font=('Arial', 11, 'bold'))
    canvas1.create_window(400, 180, window=button1)

    button2 = tk.Button (root, text='  Clear Charts  ', command=clear_charts, bg='lightskyblue2', font=('Arial', 11, 'bold'))
    canvas1.create_window(400, 220, window=button2)

    button3 = tk.Button (root, text='Exit Application', command=root.destroy, bg='lightsteelblue2', font=('Arial', 11, 'bold'))
    canvas1.create_window(400, 260, window=button3)

    root.mainloop()
    exit()


if operation == ("log"):
    print(f"log {x} is {math.log(x)}")
    print(f"log10 {x} is {math.log10(x)}")
    print(f"log1p {x} is {math.log1p(x)}")
    print(f"log2 {x} is {math.log2(x)}")
    print("-------------------------------------")
    print(f"log {y} is {math.log(y)}")
    print(f"log10 {y} is {math.log10(y)}")
    print(f"log1p {y} is {math.log1p(y)}")
    print(f"log2 {y} is {math.log2(y)}")
    input()

if operation == ("tanh"):
    print(f"the tanh of {x} is {math.tanh(x)}")
    print(f"the tanh of {y} is {math.tanh(y)}")
    input()

if operation == ("degrees"):
    print(f"{x} degree is {math.degrees(x)}")
    print(f"{y} degree is {math.degrees(y)}")
    input()

if operation == ("sinh"):
    print(f"{x} sinh = {math.sinh(x)}")
    print(f"{y} sinh =  {math.sinh(y)}")
    input()

if operation == ("factorial"):
    print(f"{x} factorial = {math.factorial(x)}")
    print(f"{y} factorial=  {math.factorial(y)}")
    input()

if operation == ("floor"):
    print(f"{x} floor = {math.floor(x)}")
    print(f"{y} floor =  {math.floor(y)}")
    input()

if operation == ("cosh"):
    print(f"{x} cosh = {math.cosh(x)}")
    print(f"{y} cosh =  {math.cosh(y)}")
    input()

if operation == ("rs code"):
    print("ok opening color resistor Calculator.........")

    from tkinter import*
    colors = ["black","brown","red","orange","yellow",
              "green","blue","violet","gray","white"]

    class Application(Frame):
        """Window to input and display resistor information"""
        def __init__(self, master):
            Frame.__init__(self, master)
            self.grid()

            self.current_colors = ["orange","orange","brown","gold"]

            self.create_elements()
        def create_elements(self):

            self.resistor = Canvas(self, width=300, height=100)
            self.resistor.config(bg="white")
            self.resistor.create_rectangle((10,10,290,90), fill="#F3C967")
            self.resistor.grid(row=0,column=0,columnspan=3)

            Label(self, text = "First band:").grid(row=1, column=0)
            self.band1 = Canvas(self, width=200, height=50)
            self.draw_colors(self.band1)
            self.band1.grid(row=1,column=1, columnspan = 2)
            self.band1.bind("<Button 1>", self.b1)

            Label(self, text = "Second band:").grid(row=2, column=0)
            self.band2 = Canvas(self, width=200, height=50)
            self.draw_colors(self.band2)
            self.band2.grid(row=2,column=1, columnspan = 2)
            self.band2.bind("<Button 1>", self.b2)

            Label(self, text = "Third band:").grid(row=3, column=0)
            self.band3 = Canvas(self, width=200, height=50)
            self.draw_colors(self.band3)
            self.band3.grid(row=3,column=1, columnspan = 2)
            self.band3.bind("<Button 1>", self.b3)

            Label(self, text = "Fourth band:").grid(row=4, column=0)
            self.band4 = Canvas(self, width=200, height=50)
            self.band4.create_rectangle((0,0,100,50),fill="gold", outline="gold")
            self.band4.create_rectangle((100,0,200,50),fill="gray", outline="gray")
            self.band4.create_text((50, 25), text="+/- 5%")
            self.band4.create_text((150, 25), text="+/- 10%")
            self.band4.grid(row=4,column=1, columnspan = 2)
            self.band4.bind("<Button 1>", self.b4)

            self.result = Text(self, width=35, height=1)
            self.result.grid(row=5,column=0, columnspan=3)

            self.update()
        def calculate(self):
            val = str(colors.index(self.current_colors[0]))+str(colors.index(self.current_colors[1]))
            for i in range(colors.index(self.current_colors[2])):
                val+="0"
            return val
        def draw_colors(self, canv):
            for i in range(10):
                canv.create_rectangle((20*i,1,20+20*i,50),fill=colors[i], outline=colors[i])
        def update(self):
            """redraw the main resistor"""
            for i in range(4):
                self.resistor.create_rectangle((60*i+40,10,60*i+70,90), fill=self.current_colors[i])
            self.result.delete(0.0, END)
            self.result.insert(END,"Resistance Value: "+self.calculate()+ " ohms")

        def change(self, band, color):
            self.current_colors[band-1] = color
            self.update()
        def b1(self, event):
            self.change(1, self.xToc(event.x))
        def b2(self, event):
            self.change(2, self.xToc(event.x))
        def b3(self, event):
            self.change(3, self.xToc(event.x))
        def b4(self, event):
            if event.x <= 100:
                self.change(4, "gold")
            else:
                self.change(4, "gray")
        def xToc(self, x):
            """converts an x value on the color selector to a color"""
            return colors[int(x/20)]
    root = Tk()
    root.title("Resistor Code Finder")
    root.iconbitmap('calc.ico')
    app = Application(root)
    root.mainloop()
    exit()

if operation == "perimetre":
    shape = input("square or rectangle? ")
    if shape == "square":
        side = int(input("Side: "))
        finalside = side + side + side + side
        print("the perimetre of square = ", finalside)
        input()

    if shape == ("rectangle"):
        lenth = int(input("Lenth: "))
        bredth = int(input("Bredth: "))
        finalperi = lenth + lenth + bredth + bredth
        print("the perimetre of rectangle  = ",finalperi)
        input()

if operation == "area":
    shape = input("square or rectangle? ")
    if shape == "square":
        side = int(input("Side: "))
        finalside = side * side
        print("the area of square = ", finalside)
        input()

    if shape == ("rectangle"):
        lenth = int(input("Lenth: "))
        bredth = int(input("Bredth: "))
        finalperi = lenth * bredth
        print("the area of rectangle  = ",finalperi)
        input()


if operation == ("draw"):
    from turtle import*
    bob = turtle.Turtle()
    turtle.title("Draw")
    shape2 = input("which shape do you want to draw? ")

    if shape2 == ("help"):
        print("here are valid commands:")
        print("1. square")
        print("2. rectangle")
        print("3. triangle")
        shape2 = input("which shape do you want to draw? ")

    if shape2 == ("rectangle"):
        color = input("border color: ")
        bgcolor2 = input("fill color: ")
        bob.pencolor(color)
        bob.fillcolor(bgcolor2)
        lenth1 = int(input("lenth of rectangle: "))
        breath1 = int(input("breadth of rectangle: "))
        bob.begin_fill()
        bob.forward(lenth1)
        bob.left(90)
        bob.forward(breath1)
        bob.left(90)
        bob.forward(lenth1)
        bob.left(90)
        bob.forward(breath1)
        bob.end_fill()
        turtle.done()

    if shape2 == ("square"):
        colorx = input("border color: ")
        bgcolor2x = input("fill color: ")
        bob.pencolor(colorx)
        bob.fillcolor(bgcolor2x)
        lenth1 = int(input("side of square: "))
        bob.begin_fill()
        bob.forward(lenth1)
        bob.left(90)
        bob.forward(lenth1)
        bob.left(90)
        bob.forward(lenth1)
        bob.left(90)
        bob.forward(lenth1)
        bob.end_fill()
        turtle.done()

    if shape2 == ("triangle"):
        colour = input("border color: ")
        bgcolour = input("fill color: ")
        size = int(input("please enter size: "))
        bob.pencolor(colour)
        bob.fillcolor(bgcolour)
        bob.begin_fill()
        bob.forward(size)
        bob.left(180-60)
        bob.forward(size)
        bob.left(180-60)
        bob.forward(size)
        bob.left(180-60)
        bob.forward(size)
        bob.end_fill()



if operation == ("no"):
    print("ok thank you :)")

print("thank you for buying this legal copy of the ultimate calculator")
print("do not distribute")
input()
