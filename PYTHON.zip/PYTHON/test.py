name = input("Whats ur name: ")
print("Hello, "+ name)