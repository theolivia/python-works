# define a list of names
names = ["Harry", "Ron", "Hermione", "Ginny", "Neville"]
names.append("Draco")
names.sort()
print(names)
