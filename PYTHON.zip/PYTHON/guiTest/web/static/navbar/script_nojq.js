function logo_rotate() {
    document.getElementById("logo_main").style.animation= '2s forwards logo_rotate'
}

function logo_rerotate() {
    document.getElementById("logo_main").style.animation = '2s forwards logo_rerotate'
}

