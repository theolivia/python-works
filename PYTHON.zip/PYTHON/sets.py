# creates an empty set
s = set()

s.add(1)
s.add(2)
s.add(3)
s.add(5)
print(s)

s.remove(2)

print(s)

print(f"The set has {len(s)} elements.")
