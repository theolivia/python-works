houses = {"Harry":"Griffindor","Draco":"Slytherin"}
houses["Hermione"] = "Griffindor"
print(houses["Harry"])
