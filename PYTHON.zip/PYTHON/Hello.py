name = input("What is ur name?")
print("Hello, "+ name)
