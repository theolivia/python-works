import _tkinter as tk
window = tk.Tk()
greeting = tk.Label(text="Hello, Tkinter")

window.mainloop()

#WORKS ONLY IN UBUNTU, MAC, WINDOWS