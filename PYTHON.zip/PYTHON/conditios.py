n =int(input("number: "))
if n > 0:
    print("your number is positive")
elif n < 0:
    print("your number is negative")
else:
    print("your number is zero")

