#import all moudules
import tkinter
from tkinter import*
import webbrowser

#tk setup
root = tkinter.Tk()
root.geometry("250x500+300+300")
root.title("")
root.iconbitmap("calc.ico")
scrollbar = Scrollbar(root)
scrollbar.pack( side = RIGHT, fill = Y )

screen_width = root.winfo_screenwidth()


#commands
new = 1
url1 = "https://shreyablog.com/home-2-2/home-2/micheal-and-chloe/"
def btn1open():
    webbrowser.open(url1,new=new),

#buttons
btn1 = Button(
    root,
    text = "Micheal And Chloe",
    font = ("arial",22),
    fg = "white",
    bg = "cyan",
    relief = GROOVE,
    command = btn1open,
    width = screen_width,
)
btn1.pack()



btn1 = Button(
    root,
    text = "Micheal And Chloe",
    font = ("arial",22),
    fg = "white",
    bg = "cyan",
    relief = GROOVE,
    border = 1,
    command = btn1open,
    width = screen_width,
)
btn1.pack()

btn1 = Button(
    root,
    text = "Micheal And Chloe",
    font = ("arial",22),
    fg = "white",
    bg = "cyan",
    relief = GROOVE,
    border = 1,
    command = btn1open,
    width = screen_width,
)
btn1.pack()

btn1 = Button(
    root,
    text = "Micheal And Chloe",
    font = ("arial",22),
    fg = "white",
    bg = "cyan",
    relief = GROOVE,
    border = 1,
    command = btn1open,
    width = screen_width,
)
btn1.pack()

btn1 = Button(
    root,
    text = "Micheal And Chloe",
    font = ("arial",22),
    fg = "white",
    bg = "cyan",
    relief = GROOVE,
    border = 1,
    command = btn1open,
    width = screen_width,
)
btn1.pack()

btn1 = Button(
    root,
    text = "Micheal And Chloe",
    font = ("arial",22),
    fg = "white",
    bg = "cyan",
    relief = GROOVE,
    border = 1,
    command = btn1open,
    width = screen_width,
)
btn1.pack()

btn1 = Button(
    root,
    text = "Micheal And Chloe",
    font = ("arial",22),
    fg = "white",
    bg = "cyan",
    relief = GROOVE,
    border = 1,
    command = btn1open,
    width = screen_width,
)
btn1.pack()

btn1 = Button(
    root,
    text = "Micheal And Chloe",
    font = ("arial",22),
    fg = "white",
    bg = "cyan",
    relief = GROOVE,
    border = 1,
    command = btn1open,
    width = screen_width,
)
btn1.pack()

btn1 = Button(
    root,
    text = "Micheal And Chloe",
    font = ("arial",22),
    fg = "white",
    bg = "cyan",
    relief = GROOVE,
    border = 1,
    command = btn1open,
    width = screen_width,
)
btn1.pack()

#execute
root.mainloop()
