x = int(input("first number: "))
y = int(input("second number: "))

result = x*y

print(f"{x} multyplied by {y} = {result}")
