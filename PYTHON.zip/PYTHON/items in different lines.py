names = ["Harry","Ron","Hermione"]

for name in names:
    print(name)

