import math
from typing import AnyStr

name = input("Name: ")
print("hello, "+name)
print("please fill these numbers")

x= int(input("first number: "))
y= int(input("second number: "))

print("=====================================")

print(f"{x} added to {y} is {x+y}")
print(f"{y} subtracted from {x} is {x-y}")
print(f"{x} multiplied to {y} is {x*y}")
print(f"{x} divided to {y} is {x/y}")

print("-------------------------------------")

print(f"{x} square is {x*x}")
print(f"{x} cube is {x*x*x}")

print("-------------------------------------")

print(f"{y} square is {y*y}")
print(f"{y} cube is {y*y*y}")

print("-------------------------------------")

print(f"the table of {x} is...")
print(f"{x} x 1 = {x}")
print(f"{x} x 2 = {x*2}")
print(f"{x} x 3 = {x*3}")
print(f"{x} x 4 = {x*4}")
print(f"{x} x 5 = {x*5}")
print(f"{x} x 6 = {x*6}")
print(f"{x} x 7 = {x*7}")
print(f"{x} x 8 = {x*8}")
print(f"{x} x 9 = {x*9}")
print(f"{x} x 10 = {x*10}")

print("-------------------------------------")

print(f"the table of {y} is...")
print(f"{y} x 2 = {y*2}")
print(f"{y} x 3 = {y*3}")
print(f"{y} x 4 = {y*4}")
print(f"{y} x 5 = {y*5}")
print(f"{y} x 6 = {y*6}")
print(f"{y} x 7 = {y*7}")
print(f"{y} x 8 = {y*8}")
print(f"{y} x 9 = {y*9}")
print(f"{y} x 10 = {y*10}")

print("-------------------------------------")

print(f"square root of {x} is {math.sqrt(x)} ")
print(f"cube root of {x} is {x**(1/3)}")

print("-------------------------------------")

print(f"square root of {y} is {math.sqrt(y)} ")
print(f"cube root of {y} is {y**(1/3)}")

print("-------------------------------------")

print(f"cos {x} = {math.cos(x)}")
print(f"sin {x} = {math.sin(x)}")
print(f"tan {x} = {math.tan(x)}")

print("-------------------------------------")

print(f"cos {y} = {math.cos(y)}")
print(f"sin {y} = {math.sin(y)}")
print(f"tan {y} = {math.tan(y)}")

print("-------------------------------------")

if (x%2 ==0):
    print(f"{x} is an even number")

else:
    print(f"{x} is a odd number")
print("-------------------------------------")

if (y%2 ==0):
    print(f"{y} is an even number")

else:
    print(f"{y} is a odd number")

print("=====================================")

like = input(f"Did you like it {name}? ")

if like == ("yes"):
    print("thank you, "+name)

if like == ("no"):
    print("sorry will improve, "+name)

print("=====================================")

more = input("would you like to try more? ")

if more == ("yes"):
    orperation = input("ok which orpration would you like: ")
    
if more == ("no"):
    print("ok thank you, "+name)

if orperation == ("log"):
    print(f"log {x} is {math.log(x)}")
    print(f"log10 {x} is {math.log10(x)}")
    print(f"log1p {x} is {math.log1p(x)}")
    print(f"log2 {x} is {math.log2(x)}")
    print("-------------------------------------")
    print(f"log {y} is {math.log(y)}")
    print(f"log10 {y} is {math.log10(y)}")
    print(f"log1p {y} is {math.log1p(y)}")
    print(f"log2 {y} is {math.log2(y)}")

if orperation == ("tanh"):
    print(f"the tanh of {x} is {math.tanh(x)}")
    print(f"the tanh of {y} is {math.tanh(y)}")
    
if orperation == ("degrees"):
    print(f"{x} degree is {math.degrees(x)}")
    print(f"{y} degree is {math.degrees(y)}")

if orperation == ("sinh"):
    print(f"{x} sinh = {math.sinh(x)}")
    print(f"{y} sinh =  {math.sinh(y)}")

if orperation == ("factorial"):
    print(f"{x} factorial = {math.factorial(x)}")
    print(f"{y} factorial=  {math.factorial(y)}")

if orperation == ("floor"):
    print(f"{x} floor = {math.floor(x)}")
    print(f"{y} floor =  {math.floor(y)}")

if orperation == ("cosh"):
    print(f"{x} cosh = {math.cosh(x)}")
    print(f"{y} cosh =  {math.cosh(y)}")

else:
    print(f"sorry {orperation} is currently not availabe {name}")







