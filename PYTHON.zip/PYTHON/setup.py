from cx_Freeze import setup, Executable

base = None    

executables = [Executable("the_ultimate_calculator.py", base=base)]

packages = ["idna"]
options = {
    'build_exe': {    
    },    
        'packages':packages,
}

setup(
    name = "<any name>",
    options = options,
    version = "<any number>",
    description = '<any description>',
    executables = executables
)
